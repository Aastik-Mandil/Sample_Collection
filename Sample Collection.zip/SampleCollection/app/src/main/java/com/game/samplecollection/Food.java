package com.game.samplecollection;

public class Food {
    private int id;
    private String name;
    //    private String price;
    private byte[] image;
    private String city;
    private String state;
    private String monsoon;
    private String sampleType;
    private String latLon;

    public Food(String name, byte[] image, int id, String city, String state, String monsoon, String sampleType, String latLon) {// String price,
        this.name = name;
//        this.price = price;
        this.image = image;
        this.id = id;
        this.city = city;
        this.state = state;
        this.monsoon = monsoon;
        this.sampleType = sampleType;
        this.latLon = latLon;
    }

    public String getCity() { return city; }

    public void setCity(String city) { this.city = city; }

    public String getState() { return state; }

    public void setState(String state) { this.state = state; }

    public String getMonsoon() { return monsoon; }

    public void setMonsoon(String monsoon) { this.monsoon = monsoon; }

    public String getSampleType() { return sampleType; }

    public void setSampleType(String sampleType) { this.sampleType = sampleType; }

    public String getLatLon() { return latLon; }

    public void setLatLon(String latLon) { this.latLon = latLon; }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public byte[] getImage() { return image; }

    public void setImage(byte[] image) { this.image = image; }
}
